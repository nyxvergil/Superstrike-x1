#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('Base','Search','Bluetooth','Printing')]
    [string]$Group
)

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$catalogPath=Join-Path $PSScriptRoot 'StrikeTasks.json'

try {
    if(-not(Test-Path -LiteralPath $catalogPath -PathType Leaf)){throw "Scheduled-task catalog missing: $catalogPath"}
    $data=Get-Content -LiteralPath $catalogPath -Raw|ConvertFrom-Json
    $catalog=[array]$data.$Group
    $tasks=@(Get-ScheduledTask -ErrorAction Stop)
    foreach($entry in $catalog){
        $path=[string]$entry.Path
        if(-not $path.StartsWith('\Microsoft\Windows\')){throw "Task path outside allowed scope: $path"}
        if($path -match 'Windows Defender|SecurityHealth|WindowsUpdate|UpdateOrchestrator|WaaSMedic'){throw "Protected task in catalog: $path"}
        $matches=@($tasks|Where-Object {($_.TaskPath+$_.TaskName) -like $path})
        if(-not $matches.Count){Write-Output "Scheduled task absent: $path";continue}
        foreach($task in $matches){
            if($task.State -ne 'Disabled'){Disable-ScheduledTask -TaskPath $task.TaskPath -TaskName $task.TaskName -ErrorAction Stop|Out-Null}
            $verify=Get-ScheduledTask -TaskPath $task.TaskPath -TaskName $task.TaskName -ErrorAction Stop
            if($verify.State -ne 'Disabled'){throw "Scheduled task verification failed: $($task.TaskPath)$($task.TaskName)"}
            Write-Output "Scheduled task disabled: $($task.TaskPath)$($task.TaskName)"
        }
    }
    exit 0
} catch {
    [Console]::Error.WriteLine("Scheduled-task group $Group failed: $($_.Exception.Message)")
    exit 1
}
