#requires -Version 5.1
[CmdletBinding()]
param([Parameter(Mandatory=$true)][ValidateSet('Temp','Thumbnails','DumpStack','Full')][string]$Mode)
$ErrorActionPreference='Stop'
$removed=0;$skipped=0;$budgetReached=$false
$clock=[Diagnostics.Stopwatch]::StartNew()
function Remove-CacheFile([string]$Path) {
    try {Remove-Item -LiteralPath $Path -Force -ErrorAction Stop;$script:removed++}
    catch [IO.IOException] {
        if(($_.Exception.HResult -band 0xffff) -notin @(32,33)){throw}
        $script:skipped++;Write-Warning "Cache file in use, retained: $Path"
    }
    catch [UnauthorizedAccessException] {$script:skipped++;Write-Warning "Cache access denied, retained: $Path"}
}
try {
    if($Mode -eq 'DumpStack'){
        foreach($name in 'DumpStack.log','DumpStack.log.tmp'){
            $file=Join-Path $env:SystemDrive $name
            if(Test-Path -LiteralPath $file -PathType Leaf){Remove-CacheFile $file}
        }
    } else {
        $targets=@()
        if($Mode -in @('Temp','Full')){$targets+=@(@{Root=$env:TEMP;Pattern='*'},@{Root=(Join-Path $env:WINDIR 'Temp');Pattern='*'})}
        if($Mode -eq 'Thumbnails'){$targets+=@{Root=(Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Explorer');Pattern='thumbcache_*.db'}}
        if($Mode -eq 'Full'){
            foreach($relative in 'Prefetch','Minidump'){$targets+=@{Root=(Join-Path $env:WINDIR $relative);Pattern='*'}}
            $targets+=@{Root=(Join-Path $env:WINDIR 'Logs');Pattern='*.log'}
            foreach($relative in 'Microsoft\Windows\INetCache','Microsoft\Windows\Temporary Internet Files','CrashDumps'){$targets+=@{Root=(Join-Path $env:LOCALAPPDATA $relative);Pattern='*'}}
            $dump=Join-Path $env:WINDIR 'MEMORY.DMP'
            if(Test-Path -LiteralPath $dump -PathType Leaf){Remove-CacheFile $dump}
        }
        foreach($target in $targets){
            $root=[IO.Path]::GetFullPath($target.Root).TrimEnd('\')
            if($root.Length -lt 8 -or $root -eq [IO.Path]::GetPathRoot($root).TrimEnd('\')){throw "Unsafe cache root: $root"}
            if(-not (Test-Path -LiteralPath $root -PathType Container)){continue}
            $pending=New-Object 'System.Collections.Generic.Stack[string]'
            $pending.Push($root)
            $scriptPath=[IO.Path]::GetFullPath($PSScriptRoot)
            while($pending.Count){
                if($clock.Elapsed.TotalSeconds -gt 85){$budgetReached=$true;Write-Warning 'Cache cleanup reached its time budget; remaining cache files were retained.';break}
                $directory=$pending.Pop()
                if((Get-Item -LiteralPath $directory).Attributes -band [IO.FileAttributes]::ReparsePoint){continue}
                try {$items=@(Get-ChildItem -LiteralPath $directory -Force)}
                catch [UnauthorizedAccessException] {$skipped++;Write-Warning "Cache directory access denied, retained: $directory";continue}
                foreach($item in $items){
                    if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){continue}
                    $resolved=[IO.Path]::GetFullPath($item.FullName)
                    if(-not $resolved.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Cache path escaped its root.'}
                    if($scriptPath.StartsWith($resolved+'\',[StringComparison]::OrdinalIgnoreCase) -or $scriptPath -eq $resolved){continue}
                    if($item.PSIsContainer){$pending.Push($resolved)}
                    elseif($item.Name -like $target.Pattern){Remove-CacheFile $resolved}
                }
            }
            if($budgetReached){break}
        }
    }
    Write-Output "Cache cleanup finished: $removed removed; $skipped locked/denied files retained; partial=$budgetReached."
    exit 0
} catch {[Console]::Error.WriteLine("Cache cleanup failed: $($_.Exception.Message)");exit 1}
