#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('Base','LeanUser','Drivers','ServiceHostSplit','Xbox','Search','Bluetooth','Printing','Touch')]
    [string]$Group
)

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$catalogPath=Join-Path $PSScriptRoot 'StrikeServices.json'
$protected='^(WinDefend|WdNisSvc|SecurityHealthService|wscsvc|BFE|mpssvc|RpcSs|DcomLaunch|EventLog|Schedule|CryptSvc|AppXSvc|ClipSVC|StateRepository|Dhcp|Dnscache|NlaSvc|AudioSrv|AudioEndpointBuilder|vgc|vgk|EasyAntiCheat|EasyAntiCheat_EOS|BEService|EAAntiCheatService)$'

try {
    if(-not(Test-Path -LiteralPath $catalogPath -PathType Leaf)){throw "Service catalog missing: $catalogPath"}
    $catalog=Get-Content -LiteralPath $catalogPath -Raw|ConvertFrom-Json
    $entries=@($catalog.$Group)
    if(-not $entries.Count){Write-Output "Service group empty: $Group";exit 0}
    if($Group -eq 'ServiceHostSplit'){
        $failures=[System.Collections.Generic.List[string]]::new()
        $retained=[System.Collections.Generic.List[string]]::new()
        $splitProtected='^(WdBoot|WdFilter|WdNisDrv|WdNisSvc|WinDefend)$'
        $eligible=0
        $configured=0
        $keys=@(Get-ChildItem -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Services' -ErrorAction Stop)
        foreach($key in $keys){
            $serviceKey=Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction Stop
            if($null -eq $serviceKey.PSObject.Properties['Start']){continue}
            $eligible++
            if($key.PSChildName -match $splitProtected){$retained.Add($key.PSChildName);continue}
            try {
                New-ItemProperty -LiteralPath $key.PSPath -Name SvcHostSplitDisable -PropertyType DWord -Value 1 -Force -ErrorAction Stop|Out-Null
                if([int](Get-ItemPropertyValue -LiteralPath $key.PSPath -Name SvcHostSplitDisable -ErrorAction Stop) -ne 1){throw 'verification failed'}
                $configured++
            } catch {
                $failures.Add("$($key.PSChildName): $($_.Exception.Message)")
            }
        }
        if($failures.Count){throw "Service-host consolidation failed for $($failures.Count) service(s): $($failures -join '; ')"}
        Write-Output "Service-host consolidation configured for $configured of $eligible eligible service keys"
        if($retained.Count){Write-Output "Protected Defender service keys retained: $($retained -join ', ')"}
        exit 0
    }
    if($Group -eq 'Drivers'){
        foreach($entry in $entries){
            $serviceName=[string]$entry.Name
            if($serviceName -notmatch '^[A-Za-z0-9_.-]+$'){throw "Invalid driver service name: $serviceName"}
            $key="HKLM:\SYSTEM\CurrentControlSet\Services\$serviceName"
            if(-not(Test-Path -LiteralPath $key)){Write-Output "Driver service absent: $serviceName";continue}
            New-ItemProperty -LiteralPath $key -Name Start -PropertyType DWord -Value 4 -Force -ErrorAction Stop|Out-Null
            if([int](Get-ItemPropertyValue -LiteralPath $key -Name Start -ErrorAction Stop) -ne 4){throw "Driver service verification failed: $serviceName"}
            Write-Output "Driver service configured: $serviceName -> Disabled after restart"
        }
        exit 0
    }
    if($Group -eq 'LeanUser'){
        foreach($entry in $entries){
            $serviceName=[string]$entry.Name
            if($serviceName -notmatch '^[A-Za-z0-9_.-]+$'){throw "Invalid user-service template name: $serviceName"}
            $key="HKLM:\SYSTEM\CurrentControlSet\Services\$serviceName"
            if(-not(Test-Path -LiteralPath $key)){Write-Output "User-service template absent: $serviceName";continue}
            New-ItemProperty -LiteralPath $key -Name Start -PropertyType DWord -Value 4 -Force -ErrorAction Stop|Out-Null
            $start=(Get-ItemProperty -LiteralPath $key -Name Start -ErrorAction Stop).Start
            if([int]$start -ne 4){throw "User-service template verification failed: $serviceName"}
            Write-Output "User-service template configured: $serviceName -> Disabled after restart"
        }
        exit 0
    }
    $services=@(Get-Service -ErrorAction Stop)
    foreach($entry in $entries){
        $serviceName=[string]$entry.Name
        if($serviceName -notmatch '^[A-Za-z0-9_.-]+$'){throw "Invalid service name in catalog: $serviceName"}
        if($serviceName -match $protected){throw "Protected service in catalog: $serviceName"}
        $matches=@($services|Where-Object Name -EQ $serviceName)
        if(-not $matches.Count){Write-Output "Service absent: $($entry.Name)";continue}
        foreach($service in $matches){
            Set-Service -Name $service.Name -StartupType ([string]$entry.Startup) -ErrorAction Stop
            $verify=Get-CimInstance Win32_Service -Filter ("Name='"+$service.Name.Replace("'","''")+"'") -ErrorAction Stop
            if($entry.Startup -eq 'Disabled' -and $verify.StartMode -ne 'Disabled'){throw "Service startup verification failed: $($service.Name)"}
            Write-Output "Service configured: $($service.Name) -> $($entry.Startup)"
        }
    }
    exit 0
} catch {
    [Console]::Error.WriteLine("Service group $Group failed: $($_.Exception.Message)")
    exit 1
}
