#requires -Version 5.1
[CmdletBinding()]
param([ValidateSet('Finish')][string]$Stage='Finish')

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

function Invoke-AuditCommand {
    param([Parameter(Mandatory=$true)][string]$File,[Parameter(Mandatory=$true)][string[]]$Arguments)
    $output=@(& $File @Arguments 2>&1)
    if($LASTEXITCODE -ne 0){throw "$([IO.Path]::GetFileName($File)) $($Arguments -join ' ') failed ($LASTEXITCODE): $($output -join ' ')"}
    $output -join "`n"
}

function Get-OptionalRegistryValue {
    param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][string]$Name)
    $item=Get-ItemProperty -LiteralPath $Path -ErrorAction SilentlyContinue
    if($null -eq $item){return $null}
    $property=$item.PSObject.Properties[$Name]
    if($null -eq $property){return $null}
    $property.Value
}

try {
    $base=Join-Path $env:ProgramData 'StrikeOS'
    $stateDir=Join-Path $base 'State'
    $reportDir=Join-Path $base 'Reports'
    New-Item -Path $stateDir,$reportDir -ItemType Directory -Force|Out-Null
    $systemPath=Join-Path $stateDir 'System.json'
    if(-not(Test-Path -LiteralPath $systemPath -PathType Leaf)){throw 'System detection state is missing.'}
    $system=Get-Content -LiteralPath $systemPath -Raw|ConvertFrom-Json
    if([int]$system.Build -notin @(19045,26100,26200)){throw "Unsupported build in system state: $($system.Build)"}

    $critical=@('BFE','mpssvc','WinDefend','EventLog','Schedule','RpcSs','DcomLaunch','CryptSvc')
    $serviceState=[Collections.Generic.List[object]]::new()
    foreach($name in $critical){
        $service=Get-CimInstance Win32_Service -Filter ("Name='"+$name+"'") -ErrorAction Stop
        if(-not $service){throw "Required service missing: $name"}
        if($service.StartMode -eq 'Disabled'){throw "Required service disabled: $name"}
        $serviceState.Add([ordered]@{Name=$name;State=$service.State;StartMode=$service.StartMode})
    }

    foreach($catalog in 'StrikeAppx-Patterns.json','StrikeServices.json','StrikeTasks.json'){
        $path=Join-Path $PSScriptRoot $catalog
        if(-not(Test-Path -LiteralPath $path -PathType Leaf)){throw "Catalog missing: $catalog"}
        $null=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json
    }

    $antiCheat=[Collections.Generic.List[object]]::new()
    foreach($name in 'vgc','vgk','EasyAntiCheat','EasyAntiCheat_EOS','BEService','EAAntiCheatService'){
        $service=Get-CimInstance Win32_Service -Filter ("Name='"+$name+"'") -ErrorAction SilentlyContinue
        if($service){$antiCheat.Add([ordered]@{Name=$name;State=$service.State;StartMode=$service.StartMode})}
    }

    $profile=[string](Get-OptionalRegistryValue -Path 'HKLM:\SOFTWARE\StrikeOS' -Name SelectedProfile)
    if([string]::IsNullOrWhiteSpace($profile)){$profile='Standard'}
    if($profile -notin @('Standard','Performance')){throw "Unknown optimization profile: $profile"}

    $fthEnabled=Get-OptionalRegistryValue -Path 'HKLM:\SOFTWARE\Microsoft\FTH' -Name Enabled
    $oneSyncStart=Get-OptionalRegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\OneSyncSvc' -Name Start
    $splitCount=@(Get-ChildItem -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Services' -ErrorAction Stop|Where-Object{
        (Get-OptionalRegistryValue -Path $_.PSPath -Name SvcHostSplitDisable) -eq 1
    }).Count
    $performance=[ordered]@{
        Profile=$profile
        FthEnabled=$fthEnabled
        OneSyncSvcStart=$oneSyncStart
        ServiceHostSplitDisableCount=$splitCount
    }

    $runtimePath=Join-Path $stateDir 'Runtimes.json'
    if(-not(Test-Path -LiteralPath $runtimePath -PathType Leaf)){throw 'Gaming runtime state is missing.'}
    $runtimeState=Get-Content -LiteralPath $runtimePath -Raw|ConvertFrom-Json
    $runtimeNames=@($runtimeState.Components.Name)
    foreach($name in 'Visual C++ 2015-2022 x86','Visual C++ 2015-2022 x64','DirectX Legacy June 2010','.NET Framework 3.5'){
        if($name -notin $runtimeNames){throw "Gaming runtime was not processed: $name"}
    }
    foreach($runtime in @($runtimeState.Components|Where-Object Name -ne '.NET Framework 3.5')){
        if([string]$runtime.State -notin @('Present','Installed')){throw "Gaming runtime is not ready: $($runtime.Name) [$($runtime.State)]"}
    }
    $netFx3=@($runtimeState.Components|Where-Object Name -eq '.NET Framework 3.5'|Select-Object -Last 1)[0]
    if([string]$netFx3.State -notin @('Present','Installed','SkippedNoSource','DeferredRestart')){throw "Unexpected .NET Framework 3.5 state: $($netFx3.State)"}
    $performance.Runtimes=$runtimeState

    if($profile -eq 'Performance'){
        $performancePath=Join-Path $stateDir 'Performance.json'
        $networkResetPath=Join-Path $stateDir 'NetworkReset.json'
        if(-not(Test-Path -LiteralPath $performancePath -PathType Leaf)){throw 'Performance profile state is missing.'}
        if(-not(Test-Path -LiteralPath $networkResetPath -PathType Leaf)){throw 'Network reset state is missing.'}
        $performanceState=Get-Content -LiteralPath $performancePath -Raw|ConvertFrom-Json
        $networkResetState=Get-Content -LiteralPath $networkResetPath -Raw|ConvertFrom-Json

        $fsutil=Join-Path $env:SystemRoot 'System32\fsutil.exe'
        $trim=Invoke-AuditCommand -File $fsutil -Arguments @('behavior','query','DisableDeleteNotify')
        if($trim -notmatch '(?im)^\s*NTFS\s+DisableDeleteNotify\s*=\s*0(?:\s|$)'){throw "TRIM audit failed: $trim"}
        $offload=Get-NetOffloadGlobalSetting -ErrorAction Stop
        $tcp=Get-NetTCPSetting -SettingName Internet -ErrorAction Stop
        if([string]$offload.ReceiveSideScaling -ne 'Enabled'){throw 'RSS audit failed.'}
        if([string]$offload.ReceiveSegmentCoalescing -ne 'Disabled'){throw 'RSC audit failed.'}
        if([string]$tcp.AutoTuningLevelLocal -ne 'Normal'){throw 'TCP Auto-Tuning audit failed.'}

        $powercfg=Join-Path $env:SystemRoot 'System32\powercfg.exe'
        $activeScheme=Invoke-AuditCommand -File $powercfg -Arguments @('/getactivescheme')
        $bcdedit=Join-Path $env:SystemRoot 'System32\bcdedit.exe'
        $bcd=Invoke-AuditCommand -File $bcdedit -Arguments @('/enum','{current}')
        if($bcd -notmatch '(?im)^useplatformclock\s+Yes\s*$'){throw 'Forced HPET audit failed.'}

        $timerTask=Get-ScheduledTask -TaskName TimerResolution -TaskPath '\StrikeOS\' -ErrorAction Stop
        $timerProcess=@(Get-Process -Name StrikeTimerResolution -ErrorAction SilentlyContinue)
        if(-not $timerProcess.Count){throw 'Timer-resolution process is not running.'}
        $hags=Get-OptionalRegistryValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -Name HwSchMode
        $msiCount=@(Get-PnpDevice -PresentOnly -ErrorAction Stop|Where-Object{
            $_.Class -in @('Display','Net') -and
            (Get-OptionalRegistryValue -Path "HKLM:\SYSTEM\CurrentControlSet\Enum\$($_.InstanceId)\Device Parameters\Interrupt Management\MessageSignaledInterruptProperties" -Name MSISupported) -eq 1
        }).Count
        $performance.PerformanceState=$performanceState
        $performance.NetworkResetState=$networkResetState
        $performance.Trim='Enabled'
        $performance.Rss=[string]$offload.ReceiveSideScaling
        $performance.Rsc=[string]$offload.ReceiveSegmentCoalescing
        $performance.AutoTuning=[string]$tcp.AutoTuningLevelLocal
        $performance.ActivePowerScheme=$activeScheme.Trim()
        $performance.Bcd=$bcd
        $performance.Hags=$hags
        $performance.MsiDeviceCount=$msiCount
        $performance.TimerTaskState=[string]$timerTask.State
        $performance.TimerProcessId=@($timerProcess.Id)
    }

    $processes=@(Get-Process|Sort-Object WorkingSet64 -Descending)
    $os=Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
    $runningServices=@(Get-CimInstance Win32_Service -Filter "State='Running'" -ErrorAction Stop)
    $topMemory=@($processes|Select-Object -First 15|ForEach-Object{[ordered]@{Name=$_.ProcessName;Id=$_.Id;WorkingSetMB=[math]::Round($_.WorkingSet64/1MB,1)}})
    $report=[ordered]@{
        Version='2.0.17'
        Stage=$Stage
        Completed=(Get-Date -Format o)
        Windows=$system
        ProcessCount=$processes.Count
        SvchostCount=@($processes|Where-Object ProcessName -eq 'svchost').Count
        RunningServiceCount=$runningServices.Count
        MemoryUsedMB=[math]::Round(([double]$os.TotalVisibleMemorySize-[double]$os.FreePhysicalMemory)/1KB,0)
        AvailableMemoryMB=[math]::Round([double]$os.FreePhysicalMemory/1KB,0)
        TopProcessesByMemory=$topMemory
        LeanProfileRequiresRestart=$true
        DefenderAndCoreServices=$serviceState
        DetectedAntiCheatServices=$antiCheat
        Optimization=$performance
        PendingReboot=[bool]$system.PendingReboot
        Status='Passed'
    }
    $reportPath=Join-Path $reportDir ('Audit-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.json')
    $report|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $reportPath -Encoding UTF8
    $report|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $stateDir 'Installed.json') -Encoding UTF8
    New-Item -Path 'HKLM:\SOFTWARE\StrikeOS' -Force|Out-Null
    New-ItemProperty -Path 'HKLM:\SOFTWARE\StrikeOS' -Name AppliedVersion -Value '2.0.17' -PropertyType String -Force|Out-Null
    Write-Output "StrikeOS audit passed. Processes=$($report.ProcessCount), available memory=$($report.AvailableMemoryMB) MB, report=$reportPath"
    exit 0
} catch {
    [Console]::Error.WriteLine("StrikeOS audit failed: $($_.Exception.Message)")
    exit 1
}
