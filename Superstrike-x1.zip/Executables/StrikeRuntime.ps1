#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('VcX86','VcX64','DirectX','NetFx3')]
    [string]$Component
)

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'StrikeProcess.ps1')

$stateDir=Join-Path $env:ProgramData 'StrikeOS\State'
$temporary=Join-Path $env:TEMP ('StrikeOS-Runtime-'+[guid]::NewGuid().ToString('N'))
$results=[Collections.Generic.List[object]]::new()

function Get-OptionalRegistryValue {
    param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][string]$Name)
    $item=Get-ItemProperty -LiteralPath $Path -ErrorAction SilentlyContinue
    if($null -eq $item){return $null}
    $property=$item.PSObject.Properties[$Name]
    if($null -eq $property){return $null}
    $property.Value
}

function Test-VcRuntime {
    param([ValidateSet('x86','x64')][string]$Architecture)
    $paths=if($Architecture -eq 'x86'){
        @('HKLM:\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes\x86','HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x86')
    } else {
        @('HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64')
    }
    foreach($path in $paths){
        if((Get-OptionalRegistryValue -Path $path -Name Installed) -eq 1){return $true}
    }
    return $false
}

function Get-VerifiedDownload {
    param([string]$Name,[string]$Url,[string]$FileName)
    $path=Join-Path $temporary $FileName
    Invoke-WebRequest -Uri $Url -OutFile $path -UseBasicParsing -TimeoutSec 180
    if(-not(Test-Path -LiteralPath $path -PathType Leaf) -or (Get-Item -LiteralPath $path).Length -lt 100KB){throw "$Name download is missing or unexpectedly small."}
    $signature=Get-AuthenticodeSignature -LiteralPath $path
    if($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Microsoft'){throw "$Name signature validation failed: $($signature.Status)"}
    $path
}

function Install-VcRuntime {
    param([ValidateSet('x86','x64')][string]$Architecture)
    $name="Visual C++ 2015-2022 $Architecture"
    if(Test-VcRuntime $Architecture){$results.Add([ordered]@{Name=$name;State='Present'});return}
    $installer=Get-VerifiedDownload -Name $name -Url "https://aka.ms/vc14/vc_redist.$Architecture.exe" -FileName "vc_redist.$Architecture.exe"
    Invoke-StrikeProcess -FilePath $installer -Arguments '/install /quiet /norestart' -TimeoutMilliseconds 300000 -SuccessCodes @(0,3010)|Out-Null
    if(-not(Test-VcRuntime $Architecture)){throw "$name installation was not verified."}
    $results.Add([ordered]@{Name=$name;State='Installed'})
}

function Test-DirectXLegacy {
    $files=@('d3dx9_43.dll','xinput1_3.dll','XAudio2_7.dll')
    $directories=@((Join-Path $env:SystemRoot 'System32'),(Join-Path $env:SystemRoot 'SysWOW64'))
    foreach($directory in $directories){foreach($file in $files){if(-not(Test-Path -LiteralPath (Join-Path $directory $file) -PathType Leaf)){return $false}}}
    return $true
}

function Install-DirectXLegacy {
    $name='DirectX Legacy June 2010'
    if(Test-DirectXLegacy){$results.Add([ordered]@{Name=$name;State='Present'});return}
    $sources=@(
        [ordered]@{Kind='Offline';Url='https://download.microsoft.com/download/8/4/A/84A35BF1-DAFE-4AE8-82AF-AD2AE20B6B14/directx_Jun2010_redist.exe';FileName='directx_Jun2010_redist.exe'},
        [ordered]@{Kind='Web';Url='https://download.microsoft.com/download/1/7/1/1718CCC4-6315-4D8E-9543-8E28A4E18C4C/dxwebsetup.exe';FileName='dxwebsetup.exe'}
    )
    $failures=[Collections.Generic.List[string]]::new()
    foreach($source in $sources){
        try {
            $installer=Get-VerifiedDownload -Name "$name $($source.Kind) installer" -Url $source.Url -FileName $source.FileName
            if($source.Kind -eq 'Offline'){
                $extract=Join-Path $temporary 'DirectX'
                New-Item -Path $extract -ItemType Directory -Force|Out-Null
                Invoke-StrikeProcess -FilePath $installer -Arguments "/Q /C /T:`"$extract`"" -TimeoutMilliseconds 180000 -SuccessCodes @(0)|Out-Null
                $setup=Join-Path $extract 'DXSETUP.exe'
                if(-not(Test-Path -LiteralPath $setup -PathType Leaf)){throw 'DirectX setup was not extracted.'}
                Invoke-StrikeProcess -FilePath $setup -Arguments '/silent' -TimeoutMilliseconds 300000 -SuccessCodes @(0,3010)|Out-Null
            } else {
                Invoke-StrikeProcess -FilePath $installer -Arguments '/Q' -TimeoutMilliseconds 300000 -SuccessCodes @(0,3010)|Out-Null
            }
            if(-not(Test-DirectXLegacy)){throw 'DirectX Legacy installation was not verified.'}
            $results.Add([ordered]@{Name=$name;State='Installed';Source=$source.Kind})
            return
        } catch {
            $failures.Add("$($source.Kind): $($_.Exception.Message)")
            Write-Output "DirectX $($source.Kind) source failed; trying the next Microsoft source."
        }
    }
    throw ('DirectX Legacy installation failed from every Microsoft source: '+($failures -join ' | '))
}

function Enable-NetFx3 {
    $name='.NET Framework 3.5'
    $feature=Get-WindowsOptionalFeature -Online -FeatureName NetFx3 -ErrorAction Stop
    $before=[string]$feature.State
    if($before -in @('Enabled','EnablePending')){$results.Add([ordered]@{Name=$name;State='Present';Detail=$before});return}
    if($before -eq 'DisablePending'){$results.Add([ordered]@{Name=$name;State='DeferredRestart';Detail=$before});return}

    $source=$null
    foreach($drive in @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)){
        $candidate=Join-Path $drive.Root 'sources\sxs'
        if((Test-Path -LiteralPath $candidate -PathType Container -ErrorAction SilentlyContinue) -and
           (Get-ChildItem -LiteralPath $candidate -Filter '*netfx3*ondemand-package*.cab' -File -ErrorAction SilentlyContinue|Select-Object -First 1)){
            $source=$candidate
            break
        }
    }
    if($before -eq 'DisabledWithPayloadRemoved' -and -not $source){
        $results.Add([ordered]@{Name=$name;State='SkippedNoSource';Detail='Mount matching Windows installation media to provide sources\sxs.'})
        return
    }

    $dism=Join-Path $env:SystemRoot 'System32\dism.exe'
    $arguments='/Online /Enable-Feature /FeatureName:NetFx3 /All /LimitAccess /NoRestart'
    if($source){$arguments+=' /Source:"'+$source+'"'}
    Invoke-StrikeProcess -FilePath $dism -Arguments $arguments -TimeoutMilliseconds 180000 -SuccessCodes @(0,3010)|Out-Null
    $after=Get-WindowsOptionalFeature -Online -FeatureName NetFx3 -ErrorAction Stop
    if([string]$after.State -notin @('Enabled','EnablePending')){throw ".NET Framework 3.5 installation was not verified: $($after.State)"}
    $results.Add([ordered]@{Name=$name;State='Installed';Detail=[string]$after.State;Source=if($source){$source}else{'ComponentStore'}})
}

try {
    New-Item -Path $temporary,$stateDir -ItemType Directory -Force|Out-Null
    switch($Component){
        VcX86 {Install-VcRuntime -Architecture x86}
        VcX64 {Install-VcRuntime -Architecture x64}
        DirectX {Install-DirectXLegacy}
        NetFx3 {Enable-NetFx3}
    }
    $statePath=Join-Path $stateDir 'Runtimes.json'
    $previous=@()
    if(Test-Path -LiteralPath $statePath -PathType Leaf){$previous=@((Get-Content -LiteralPath $statePath -Raw|ConvertFrom-Json).Components)}
    $combined=@($previous)+@($results)
    $components=@(foreach($name in @($combined.Name|Select-Object -Unique)){@($combined|Where-Object Name -eq $name|Select-Object -Last 1)[0]})
    $restartComponents=@($components|Where-Object{
        $detailProperty=$_.PSObject.Properties['Detail']
        $_.State -eq 'DeferredRestart' -or ($detailProperty -and [string]$detailProperty.Value -eq 'EnablePending')
    })
    $state=[ordered]@{Completed=(Get-Date -Format o);Components=$components;RequiresRestart=[bool]$restartComponents.Count}
    $state|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $statePath -Encoding UTF8
    foreach($result in $results){
        $message="$($result.Name): $($result.State)"
        if($result.Contains('Detail')){$message+=" ($($result.Detail))"}
        Write-Output $message
    }
    exit 0
} catch {
    [Console]::Error.WriteLine("Gaming runtime installation failed [$Component]: $($_.Exception.Message)")
    exit 1
} finally {
    if(Test-Path -LiteralPath $temporary){Remove-Item -LiteralPath $temporary -Recurse -Force -ErrorAction SilentlyContinue}
}
