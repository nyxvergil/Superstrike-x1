#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('Chrome','Firefox','Brave')]
    [string]$Package
)

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'StrikeProcess.ps1')

$catalog=@{
    Chrome=@{
        Url='https://dl.google.com/dl/chrome/install/googlechromestandaloneenterprise64.msi'
        File='GoogleChrome.msi'
        Publisher='Google'
        Executable=@("$env:ProgramFiles\Google\Chrome\Application\chrome.exe","${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe","$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")
        Installer='msiexec.exe'
        Arguments='/i "{0}" /qn /norestart'
    }
    Firefox=@{
        Url='https://download.mozilla.org/?product=firefox-latest-ssl&os=win64&lang=en-US'
        File='FirefoxSetup.exe'
        Publisher='Mozilla'
        Executable=@("$env:ProgramFiles\Mozilla Firefox\firefox.exe","${env:ProgramFiles(x86)}\Mozilla Firefox\firefox.exe","$env:LOCALAPPDATA\Mozilla Firefox\firefox.exe")
        Installer='{0}'
        Arguments='/S'
    }
    Brave=@{
        Url='https://github.com/brave/brave-browser/releases/latest/download/BraveBrowserStandaloneSetup.exe'
        File='BraveSetup.exe'
        Publisher='Brave'
        Executable=@("$env:ProgramFiles\BraveSoftware\Brave-Browser\Application\brave.exe","${env:ProgramFiles(x86)}\BraveSoftware\Brave-Browser\Application\brave.exe","$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\Application\brave.exe")
        Installer='{0}'
        Arguments='/silent /install'
    }
}

function Test-BrowserInstalled($Spec){return [bool]@($Spec.Executable|Where-Object{$_ -and (Test-Path -LiteralPath $_ -PathType Leaf)}).Count}

try {
    $spec=$catalog[$Package]
    if(Test-BrowserInstalled $spec){Write-Output "$Package is already installed.";exit 0}
    $temporary=Join-Path $env:TEMP ('StrikeOS-Browser-'+[guid]::NewGuid().ToString('N'))
    New-Item -Path $temporary -ItemType Directory -Force|Out-Null
    try {
        $installer=Join-Path $temporary $spec.File
        Invoke-WebRequest -Uri $spec.Url -OutFile $installer -UseBasicParsing -TimeoutSec 180
        if(-not(Test-Path -LiteralPath $installer -PathType Leaf) -or (Get-Item -LiteralPath $installer).Length -lt 1MB){throw 'Downloaded installer is missing or unexpectedly small.'}
        $signature=Get-AuthenticodeSignature -LiteralPath $installer
        if($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch $spec.Publisher){throw "Installer signature validation failed: $($signature.Status)"}
        $executable=if($spec.Installer -eq '{0}'){$installer}else{$spec.Installer}
        $arguments=if($spec.Arguments -match '\{0\}'){$spec.Arguments -f $installer}else{$spec.Arguments}
        Invoke-StrikeProcess -FilePath $executable -Arguments $arguments -TimeoutMilliseconds 420000 -SuccessCodes @(0,3010)|Write-Output
        if(-not(Test-BrowserInstalled $spec)){throw "$Package installation completed but its executable was not found."}
        Write-Output "$Package installed and verified."
    } finally {
        if(Test-Path -LiteralPath $temporary){Remove-Item -LiteralPath $temporary -Recurse -Force -ErrorAction SilentlyContinue}
    }
    exit 0
} catch {
    [Console]::Error.WriteLine("$Package installation failed: $($_.Exception.Message)")
    exit 1
}
