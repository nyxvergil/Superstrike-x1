using System;
using System.Runtime.InteropServices;
using System.Threading;

internal static class Program
{
    [DllImport("ntdll.dll")]
    private static extern int NtQueryTimerResolution(out uint minimum, out uint maximum, out uint current);

    [DllImport("ntdll.dll")]
    private static extern int NtSetTimerResolution(uint requested, bool set, out uint current);

    private static readonly ManualResetEvent StopEvent = new ManualResetEvent(false);

    private static int Main()
    {
        bool created;
        using (var mutex = new Mutex(true, "StrikeTimerResolution-05ms", out created))
        {
            if (!created)
                return 0;

            uint minimum;
            uint maximum;
            uint current;
            if (NtQueryTimerResolution(out minimum, out maximum, out current) != 0)
                return 2;

            const uint requested = 5000;
            if (requested < maximum || requested > minimum)
                return 3;

            if (NtSetTimerResolution(requested, true, out current) != 0)
                return 4;

            Console.CancelKeyPress += delegate(object sender, ConsoleCancelEventArgs args)
            {
                args.Cancel = true;
                StopEvent.Set();
            };
            AppDomain.CurrentDomain.ProcessExit += delegate { StopEvent.Set(); };

            StopEvent.WaitOne();
            NtSetTimerResolution(requested, false, out current);
            GC.KeepAlive(mutex);
            return 0;
        }
    }
}
