#requires -Version 5.1
[CmdletBinding()]
param()

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

try {
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    $principal=[Security.Principal.WindowsPrincipal]::new($identity)
    if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator rights are required.'}

    $cv=Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
    $build=[int]$cv.CurrentBuildNumber
    $display=[string]$cv.DisplayVersion
    $supported=($build -eq 19045 -and $display -eq '22H2') -or
               ($build -eq 26100 -and $display -eq '24H2') -or
               ($build -eq 26200 -and $display -eq '25H2')
    if(-not $supported){throw "Unsupported Windows: build=$build, version=$display"}

    $architecture=if($env:PROCESSOR_ARCHITEW6432){$env:PROCESSOR_ARCHITEW6432}else{$env:PROCESSOR_ARCHITECTURE}
    if($architecture -ne 'AMD64' -or -not [Environment]::Is64BitOperatingSystem){throw "Windows x64 is required: $architecture"}

    $cpu=@(Get-CimInstance Win32_Processor -ErrorAction Stop|ForEach-Object Name)
    $gpu=@(Get-CimInstance Win32_VideoController -ErrorAction Stop|ForEach-Object Name)
    $battery=@(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)
    $systemDrive=Get-CimInstance Win32_LogicalDisk -Filter ("DeviceID='"+$env:SystemDrive+"'") -ErrorAction Stop
    $pending=(Test-Path -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') -or
             (Test-Path -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')

    $stateDir=Join-Path $env:ProgramData 'StrikeOS\State'
    New-Item -Path $stateDir -ItemType Directory -Force|Out-Null
    $state=[ordered]@{
        Version='2.0.17'
        DetectedAt=(Get-Date -Format o)
        Build=$build
        DisplayVersion=$display
        Edition=[string]$cv.EditionID
        Architecture=$architecture
        FormFactor=if($battery.Count){'Laptop'}else{'Desktop'}
        CPU=$cpu
        GPU=$gpu
        FreeSystemDriveGB=[math]::Round([double]$systemDrive.FreeSpace/1GB,2)
        PendingReboot=[bool]$pending
    }
    $temporary=Join-Path $stateDir ('System-'+[guid]::NewGuid().ToString('N')+'.tmp')
    $destination=Join-Path $stateDir 'System.json'
    $state|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $temporary -Encoding UTF8
    Move-Item -LiteralPath $temporary -Destination $destination -Force
    Write-Output ("System supported: {0} {1}, build {2}, {3}, {4}" -f $cv.ProductName,$display,$build,$architecture,$state.FormFactor)
    if($pending){Write-Warning 'Windows has a pending reboot. StrikeOS will continue; restart after AME Wizard completes.'}
    exit 0
} catch {
    [Console]::Error.WriteLine("System detection failed: $($_.Exception.Message)")
    exit 1
}
