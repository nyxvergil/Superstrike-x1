#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('Apply','NetworkReset')]
    [string]$Mode
)

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'StrikeProcess.ps1')

$system32=Join-Path $env:SystemRoot 'System32'
$stateDir=Join-Path $env:ProgramData 'StrikeOS\State'
$runtimeDir=Join-Path $env:ProgramData 'StrikeOS\Runtime'

function Invoke-SystemCommand {
    param([Parameter(Mandatory=$true)][string]$Name,[Parameter(Mandatory=$true)][string]$Arguments,[int[]]$SuccessCodes=@(0),[int]$Timeout=60000)
    $path=Join-Path $system32 $Name
    if(-not(Test-Path -LiteralPath $path -PathType Leaf)){throw "System executable missing: $path"}
    Invoke-StrikeProcess -FilePath $path -Arguments $Arguments -TimeoutMilliseconds $Timeout -SuccessCodes $SuccessCodes
}

function Get-TrimState {
    $output=[string](Invoke-SystemCommand -Name 'fsutil.exe' -Arguments 'behavior query DisableDeleteNotify')
    $match=[regex]::Match($output,'(?im)^\s*NTFS\s+DisableDeleteNotify\s*=\s*([01])(?:\s|$)')
    if(-not $match.Success){throw "Unable to parse NTFS TRIM state: $output"}
    [int]$match.Groups[1].Value
}

function Set-StorageProfile {
    if((Get-TrimState) -ne 0){
        Invoke-SystemCommand -Name 'fsutil.exe' -Arguments 'behavior set DisableDeleteNotify 0'|Out-Null
    }
    if((Get-TrimState) -ne 0){throw 'NTFS TRIM verification failed'}
    Write-Output 'Storage profile verified: NTFS TRIM enabled'
}

function Set-NetworkProfile {
    Invoke-SystemCommand -Name 'netsh.exe' -Arguments 'interface tcp set global rss=enabled autotuninglevel=normal rsc=disabled'|Out-Null

    $offload=Get-NetOffloadGlobalSetting -ErrorAction Stop
    if([string]$offload.ReceiveSideScaling -ne 'Enabled'){throw 'RSS verification failed'}
    if([string]$offload.ReceiveSegmentCoalescing -ne 'Disabled'){throw 'RSC verification failed'}
    $internet=Get-NetTCPSetting -SettingName Internet -ErrorAction Stop
    if([string]$internet.AutoTuningLevelLocal -ne 'Normal'){throw 'TCP Auto-Tuning verification failed'}

    $nicChanges=[Collections.Generic.List[object]]::new()
    $nicSkipped=[Collections.Generic.List[object]]::new()
    $keywords=@('*EEE','EEELinkAdvertisement','*FlowControl','*InterruptModeration','*LsoV2IPv4','*LsoV2IPv6')
    $adapters=@(Get-NetAdapter -Physical -ErrorAction Stop|Where-Object Status -eq 'Up')
    foreach($adapter in $adapters){
        $properties=@(Get-NetAdapterAdvancedProperty -Name $adapter.Name -AllProperties -ErrorAction Stop)
        foreach($keyword in $keywords){
            $property=$properties|Where-Object RegistryKeyword -eq $keyword|Select-Object -First 1
            if(-not $property){continue}
            if($property.ValidRegistryValues -and '0' -notin @($property.ValidRegistryValues|ForEach-Object{[string]$_})){
                $nicSkipped.Add([ordered]@{Adapter=$adapter.Name;Keyword=$keyword;Reason='Driver does not expose registry value 0'})
                continue
            }
            Set-NetAdapterAdvancedProperty -Name $adapter.Name -RegistryKeyword $keyword -RegistryValue 0 -NoRestart -ErrorAction Stop
            $verify=Get-NetAdapterAdvancedProperty -Name $adapter.Name -RegistryKeyword $keyword -AllProperties -ErrorAction Stop
            if(0 -notin @($verify.RegistryValue)){throw "NIC property verification failed: $($adapter.Name)/$keyword"}
            $nicChanges.Add([ordered]@{Adapter=$adapter.Name;Keyword=$keyword;Value=0})
        }
    }
    [ordered]@{Rss='Enabled';AutoTuning='Normal';Rsc='Disabled';Changed=@($nicChanges);Skipped=@($nicSkipped)}
}

function Set-PowerProfile {
    $isLaptop=@(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue).Count -gt 0
    if(-not $isLaptop){Invoke-SystemCommand -Name 'powercfg.exe' -Arguments '/setactive SCHEME_MIN'|Out-Null}
    $aliases=[string](Invoke-SystemCommand -Name 'powercfg.exe' -Arguments '/aliases')
    $settings=@('CPMINCORES','PROCTHROTTLEMIN','PROCTHROTTLEMAX')
    if($aliases -match '(?im)\bCPMINCORES1\b'){$settings+='CPMINCORES1'}
    foreach($setting in $settings){
        Invoke-SystemCommand -Name 'powercfg.exe' -Arguments "/setacvalueindex SCHEME_CURRENT SUB_PROCESSOR $setting 100"|Out-Null
        if(-not $isLaptop){Invoke-SystemCommand -Name 'powercfg.exe' -Arguments "/setdcvalueindex SCHEME_CURRENT SUB_PROCESSOR $setting 100"|Out-Null}
    }
    Invoke-SystemCommand -Name 'powercfg.exe' -Arguments '/setactive SCHEME_CURRENT'|Out-Null
    $active=[string](Invoke-SystemCommand -Name 'powercfg.exe' -Arguments '/getactivescheme')
    if($active -notmatch '(?i)[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}'){throw "Active power scheme verification failed: $active"}
    [ordered]@{Laptop=$isLaptop;ActiveScheme=$active.Trim();Settings=$settings;CoreParkingAC=100;CoreParkingDC=if($isLaptop){'Unchanged'}else{100}}
}

function Set-DeviceProfile {
    $graphicsKey='HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers'
    $display=@(Get-PnpDevice -PresentOnly -Class Display -ErrorAction Stop|Where-Object FriendlyName -NotMatch 'Microsoft Basic')
    if($display.Count){
        New-ItemProperty -LiteralPath $graphicsKey -Name HwSchMode -PropertyType DWord -Value 2 -Force -ErrorAction Stop|Out-Null
        if([int](Get-ItemPropertyValue -LiteralPath $graphicsKey -Name HwSchMode -ErrorAction Stop) -ne 2){throw 'HAGS verification failed'}
    }

    $msiChanges=[Collections.Generic.List[string]]::new()
    $devices=@(Get-PnpDevice -PresentOnly -ErrorAction Stop|Where-Object{
        $_.Class -in @('Display','Net') -and $_.FriendlyName -notmatch 'Microsoft Basic|Virtual|VPN|TAP|WAN Miniport|Loopback'
    })
    foreach($device in $devices){
        $path="HKLM:\SYSTEM\CurrentControlSet\Enum\$($device.InstanceId)\Device Parameters\Interrupt Management\MessageSignaledInterruptProperties"
        if(-not(Test-Path -LiteralPath $path)){continue}
        $existing=Get-ItemProperty -LiteralPath $path -ErrorAction Stop
        if($null -eq $existing.PSObject.Properties['MSISupported']){continue}
        New-ItemProperty -LiteralPath $path -Name MSISupported -PropertyType DWord -Value 1 -Force -ErrorAction Stop|Out-Null
        if([int](Get-ItemPropertyValue -LiteralPath $path -Name MSISupported -ErrorAction Stop) -ne 1){throw "MSI verification failed: $($device.FriendlyName)"}
        $msiChanges.Add($device.FriendlyName)
    }
    [ordered]@{Hags=if($display.Count){'Enabled'}else{'No supported display device'};MsiDevices=@($msiChanges)}
}

function Install-TimerResolution {
    New-Item -Path $runtimeDir -ItemType Directory -Force|Out-Null
    $source=Join-Path $PSScriptRoot 'StrikeTimerResolution.cs'
    $exe=Join-Path $runtimeDir 'StrikeTimerResolution.exe'
    if(-not(Test-Path -LiteralPath $source -PathType Leaf)){throw "Timer source missing: $source"}
    if(-not(Test-Path -LiteralPath $exe -PathType Leaf)){
        $provider=New-Object Microsoft.CSharp.CSharpCodeProvider
        $parameters=New-Object System.CodeDom.Compiler.CompilerParameters
        $parameters.GenerateExecutable=$true
        $parameters.GenerateInMemory=$false
        $parameters.OutputAssembly=$exe
        $parameters.CompilerOptions='/optimize+ /platform:anycpu /target:winexe'
        [void]$parameters.ReferencedAssemblies.Add('System.dll')
        $result=$provider.CompileAssemblyFromFile($parameters,$source)
        $provider.Dispose()
        if($result.Errors.HasErrors){throw "Timer compilation failed: $(@($result.Errors|ForEach-Object ToString) -join '; ')"}
    }

    $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
    $action=New-ScheduledTaskAction -Execute $exe
    $trigger=New-ScheduledTaskTrigger -AtLogOn -User $identity.Name
    $principal=New-ScheduledTaskPrincipal -UserId $identity.User.Value -LogonType Interactive -RunLevel Highest
    $settings=New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
    Register-ScheduledTask -TaskName 'TimerResolution' -TaskPath '\StrikeOS\' -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force -ErrorAction Stop|Out-Null
    if(-not(Get-Process -Name StrikeTimerResolution -ErrorAction SilentlyContinue)){Start-ScheduledTask -TaskName 'TimerResolution' -TaskPath '\StrikeOS\' -ErrorAction Stop}
    $deadline=[DateTime]::UtcNow.AddSeconds(10)
    do {
        if(Get-Process -Name StrikeTimerResolution -ErrorAction SilentlyContinue){return $exe}
        Start-Sleep -Milliseconds 250
    } while([DateTime]::UtcNow -lt $deadline)
    throw 'Timer-resolution process did not start'
}

function Reset-NetworkProfile {
    $resetLog=Join-Path $env:ProgramData 'StrikeOS\Reports\NetworkReset.log'
    New-Item -Path (Split-Path $resetLog -Parent) -ItemType Directory -Force|Out-Null
    $winsock=[string](Invoke-SystemCommand -Name 'netsh.exe' -Arguments 'winsock reset')
    $netsh=Join-Path $system32 'netsh.exe'
    $ipResult=Invoke-StrikeProcess -FilePath $netsh -Arguments "interface ip reset `"$resetLog`"" -TimeoutMilliseconds 60000 -SuccessCodes @(0,1) -PassThru
    $ipText=([string]$ipResult.Output)+([string]$ipResult.Error)
    $ipState='Complete'
    if($ipResult.ExitCode -eq 1){
        $successfulResets=[regex]::Matches($ipText,'(?im),\s*OK!\s*$').Count
        $failedResets=[regex]::Matches($ipText,'(?im),\s*failed\.\s*$').Count
        if($successfulResets -lt 1 -or $failedResets -lt 1){throw "IP reset returned 1 without a verifiable partial result: $ipText"}
        $ipState='PartialProtectedKey'
        Write-Warning "IP reset completed with $successfulResets successful entries and $failedResets protected entry; restart is still required. Log=$resetLog"
    }
    Invoke-SystemCommand -Name 'ipconfig.exe' -Arguments '/flushdns'|Out-Null
    $network=Set-NetworkProfile
    [ordered]@{Winsock='Complete';IpReset=$ipState;ExitCode=[int]$ipResult.ExitCode;Network=$network;Log=$resetLog}
}

try {
    New-Item -Path $stateDir -ItemType Directory -Force|Out-Null
    if($Mode -eq 'NetworkReset'){
        $reset=Reset-NetworkProfile
        $resetState=[ordered]@{Completed=(Get-Date -Format o);RequiresRestart=$true;Reset=$reset}
        $resetState|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $stateDir 'NetworkReset.json') -Encoding UTF8
        Write-Output "Winsock/IP reset processed; DNS cache flushed; TCP profile reapplied. IP state=$($reset.IpReset)"
        exit 0
    }

    Set-StorageProfile
    $network=Set-NetworkProfile
    $power=Set-PowerProfile
    $device=Set-DeviceProfile
    $timer=Install-TimerResolution
    $state=[ordered]@{
        Profile='Performance'
        Applied=(Get-Date -Format o)
        Trim='Enabled'
        Rss='Enabled'
        AutoTuning='Normal'
        Rsc='Disabled'
        NetworkAdapterChanges=$network
        Power=$power
        Devices=$device
        TimerResolution100ns=5000
        TimerExecutable=$timer
        RequiresRestart=$true
    }
    $state|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $stateDir 'Performance.json') -Encoding UTF8
    Write-Output 'Performance profile applied and verified'
    exit 0
} catch {
    [Console]::Error.WriteLine("StrikeOS system profile failed [$Mode]: $($_.Exception.Message)")
    exit 1
}
