#requires -Version 5.1
[CmdletBinding()]
param()

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

function Set-Wallpaper([string]$Source,[string]$Target) {
    Copy-Item -LiteralPath $Source -Destination $Target -Force
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class StrikeWallpaper {
    [DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
    public static extern bool SystemParametersInfo(uint action, uint parameter, string value, uint flags);
}
'@
    if(-not[StrikeWallpaper]::SystemParametersInfo(20,0,$Target,3)){throw "Wallpaper API failed: $([Runtime.InteropServices.Marshal]::GetLastWin32Error())"}
    New-Item -Path 'HKCU:\Control Panel\Desktop' -Force|Out-Null
    New-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name Wallpaper -Value $Target -PropertyType String -Force|Out-Null
    New-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name WallpaperStyle -Value '10' -PropertyType String -Force|Out-Null
    New-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name TileWallpaper -Value '0' -PropertyType String -Force|Out-Null
}

function Set-LockScreen([string]$Source,[string]$Target) {
    Add-Type -AssemblyName System.Drawing
    $image=[Drawing.Image]::FromFile($Source)
    try {
        $bitmap=[Drawing.Bitmap]::new($image.Width,$image.Height)
        try {
            $graphics=[Drawing.Graphics]::FromImage($bitmap)
            try {$graphics.DrawImage($image,0,0,$image.Width,$image.Height)} finally {$graphics.Dispose()}
            $bitmap.Save($Target,[Drawing.Imaging.ImageFormat]::Jpeg)
        } finally {$bitmap.Dispose()}
    } finally {$image.Dispose()}
    $policy='HKLM:\SOFTWARE\Policies\Microsoft\Windows\Personalization'
    New-Item -Path $policy -Force|Out-Null
    New-ItemProperty -Path $policy -Name LockScreenImage -Value $Target -PropertyType String -Force|Out-Null
    if((Get-ItemPropertyValue -LiteralPath $policy -Name LockScreenImage) -ne $Target){throw 'Lock-screen policy verification failed.'}
}

function Set-Avatar([string]$Source,[string]$Directory) {
    Add-Type -AssemblyName System.Drawing
    $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $accountKey="HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AccountPicture\Users\$sid"
    New-Item -Path $accountKey -Force|Out-Null
    $sourceImage=[Drawing.Image]::FromFile($Source)
    try {
        foreach($size in 32,40,48,96,192,240,448,1080){
            $target=Join-Path $Directory ("avatar-$size.png")
            $bitmap=[Drawing.Bitmap]::new($size,$size)
            try {
                $graphics=[Drawing.Graphics]::FromImage($bitmap)
                try {
                    $graphics.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                    $graphics.DrawImage($sourceImage,0,0,$size,$size)
                } finally {$graphics.Dispose()}
                $bitmap.Save($target,[Drawing.Imaging.ImageFormat]::Png)
            } finally {$bitmap.Dispose()}
            New-ItemProperty -Path $accountKey -Name ("Image$size") -Value $target -PropertyType String -Force|Out-Null
        }
    } finally {$sourceImage.Dispose()}
}

try {
    $directory=Join-Path $env:ProgramData 'StrikeOS\Appearance'
    New-Item -Path $directory -ItemType Directory -Force|Out-Null

    $wallpaper=Join-Path $PSScriptRoot 'wallpaper.jpg'
    if(-not(Test-Path -LiteralPath $wallpaper -PathType Leaf)){$wallpaper=Join-Path $PSScriptRoot 'img100.jpg'}
    if(Test-Path -LiteralPath $wallpaper -PathType Leaf){Set-Wallpaper $wallpaper (Join-Path $directory 'wallpaper.jpg');Write-Output 'Wallpaper applied.'}
    else{Write-Output 'Wallpaper image absent; skipped.'}

    $lockscreen=Join-Path $PSScriptRoot 'lockscreen.jpg'
    if(Test-Path -LiteralPath $lockscreen -PathType Leaf){Set-LockScreen $lockscreen (Join-Path $directory 'lockscreen.jpg');Write-Output 'Lock-screen policy applied.'}
    else{Write-Output 'Lock-screen image absent; skipped.'}

    $avatar=Join-Path $PSScriptRoot 'avatar.png'
    if(Test-Path -LiteralPath $avatar -PathType Leaf){Set-Avatar $avatar $directory;Write-Output 'User avatar applied.'}
    else{Write-Output 'User-avatar image absent; skipped.'}
    exit 0
} catch {
    [Console]::Error.WriteLine("Appearance configuration failed: $($_.Exception.Message)")
    exit 1
}
