#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateSet('Feature','Capability')][string]$Kind,
    [Parameter(Mandatory=$true)][ValidatePattern('^[A-Za-z0-9.~-]+$')][string]$Name
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$before='Unknown';$after='Unknown';$restartNeeded=$false
$directory=Join-Path $env:ProgramData 'StrikeOS\Logs'
$journal=Join-Path $directory 'Component-Results.jsonl'
$dismLog=Join-Path $directory ('DISM-'+$Kind+'-'+$Name+'.log')
function Write-ComponentResult([string]$Status,[string]$Detail) {
    [ordered]@{Time=(Get-Date -Format o);Kind=$Kind;Name=$Name;Status=$Status;Before=$before;After=$after;RestartNeeded=$restartNeeded;Detail=$Detail;DismLog=$dismLog} |
        ConvertTo-Json -Compress | Add-Content -LiteralPath $journal -Encoding UTF8
    Write-Output "Component $Status [$Kind/$Name]: before=$before; after=$after; restart=$restartNeeded. $Detail"
}
function Read-State {
    if($Kind -eq 'Feature'){$items=@(Get-WindowsOptionalFeature -Online -LogPath $dismLog | Where-Object FeatureName -EQ $Name)}
    else {$items=@(Get-WindowsCapability -Online -LimitAccess -LogPath $dismLog | Where-Object Name -EQ $Name)}
    if($items.Count -gt 1){throw "Ambiguous component identity: $Name"}
    if(-not $items.Count){return 'Absent'}
    return [string]$items[0].State
}
try {
    New-Item -ItemType Directory -Path $directory -Force | Out-Null
    if($Name -match 'Defender|SecHealth'){throw 'Defender component removal is not allowed.'}
    Write-ComponentResult 'Begin' 'Querying exact component; no package-store edits.'
    $before=Read-State
    $after=$before
    Write-ComponentResult 'ObservedBefore' 'Current Windows servicing state.'
    if($before -eq 'Absent'){Write-ComponentResult 'Absent' 'Component is not available on this image.';exit 0}
    $pendingState=if($Kind -eq 'Feature'){'DisablePending'}else{'UninstallPending'}
    $removedStates=if($Kind -eq 'Feature'){@('Disabled','DisabledWithPayloadRemoved')}else{@('NotPresent','Removed')}
    $installedState=if($Kind -eq 'Feature'){'Enabled'}else{'Installed'}
    if($before -eq $pendingState){$restartNeeded=$true;Write-ComponentResult 'PendingReboot' 'Removal already pending; not issuing it again or reporting it as removed.';exit 0}
    if($before -in $removedStates){Write-ComponentResult 'Verified' 'Already in the requested state.';exit 0}
    if($before -ne $installedState){throw "Unexpected initial servicing state: $before"}
    Write-ComponentResult 'RemovalRequested' 'Waiting for DISM; a timeout is not success.'
    if($Kind -eq 'Feature'){
        $result=@(Disable-WindowsOptionalFeature -Online -FeatureName $Name -NoRestart -LogPath $dismLog)
    } else {
        $result=@(Remove-WindowsCapability -Online -Name $Name -LogPath $dismLog)
    }
    foreach($item in $result){
        $property=$item.PSObject.Properties['RestartNeeded']
        if($null -ne $property){
            if($property.Value -isnot [bool]){throw 'Invalid RestartNeeded result from DISM.'}
            if($property.Value){$restartNeeded=$true}
        }
    }
    $after=Read-State
    if($after -eq $pendingState -or ($after -eq $installedState -and $restartNeeded)){
        $restartNeeded=$true
        Write-ComponentResult 'PendingReboot' 'DISM indicates deferred servicing. Not verified removed; recheck after reboot.'
    } elseif($after -in $removedStates -or $after -eq 'Absent') {
        Write-ComponentResult 'Verified' 'Read-back confirms the requested state.'
    } else {throw "Removal not verified: before=$before; after=$after; RestartNeeded=$restartNeeded"}
    exit 0
} catch {
    $failure=$_.Exception.Message
    try {Write-ComponentResult 'Failed' $failure}catch {[Console]::Error.WriteLine("Component journal failed: $($_.Exception.Message)")}
    [Console]::Error.WriteLine("Component failed [$Name]: $failure. DISM log: $dismLog")
    exit 1
}
