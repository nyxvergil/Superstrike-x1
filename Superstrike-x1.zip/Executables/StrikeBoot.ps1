#requires -Version 5.1
[CmdletBinding()]
param([switch]$ForceHpet)

$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest

try {
    $bcd=Join-Path $env:SystemRoot 'System32\bcdedit.exe'
    if(-not(Test-Path -LiteralPath $bcd -PathType Leaf)){throw "BCDEdit missing: $bcd"}
    $commands=[Collections.Generic.List[object]]::new()
    $commands.Add(@('/set','{current}','disabledynamictick','yes'))
    if($ForceHpet){$commands.Add(@('/set','{current}','useplatformclock','yes'))}
    else{$commands.Add(@('/deletevalue','{current}','useplatformclock'))}
    $commands.Add(@('/set','{current}','useplatformtick','yes'))
    $commands.Add(@('/set','{current}','tscsyncpolicy','enhanced'))
    foreach($arguments in $commands){
        $output=@(& $bcd @arguments 2>&1)
        $code=$LASTEXITCODE
        if($code -ne 0 -and $arguments[0] -ne '/deletevalue'){
            throw "BCDEdit $($arguments -join ' ') failed ($code): $($output -join ' ')"
        }
    }
    $state=(@(& $bcd /enum '{current}' 2>&1) -join "`n")
    if($LASTEXITCODE -ne 0){throw "Unable to verify current BCD entry: $state"}
    if($state -notmatch '(?im)^disabledynamictick\s+Yes\s*$'){throw 'disabledynamictick verification failed'}
    if($ForceHpet){
        if($state -notmatch '(?im)^useplatformclock\s+Yes\s*$'){throw 'useplatformclock verification failed'}
    } elseif($state -match '(?im)^useplatformclock\s+'){
        throw 'useplatformclock removal verification failed'
    }
    if($state -notmatch '(?im)^useplatformtick\s+Yes\s*$'){throw 'useplatformtick verification failed'}
    if($state -notmatch '(?im)^tscsyncpolicy\s+Enhanced\s*$'){throw 'tscsyncpolicy verification failed'}
    Write-Output 'BCD timer configuration applied and verified'
    exit 0
} catch {
    [Console]::Error.WriteLine("BCD timer configuration failed: $($_.Exception.Message)")
    exit 1
}
