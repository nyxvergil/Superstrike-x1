#requires -Version 5.1
function Invoke-StrikeProcess {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$FilePath,[string]$Arguments,[int]$TimeoutMilliseconds=30000,[int[]]$SuccessCodes=@(0),[switch]$PassThru)
    $info=New-Object Diagnostics.ProcessStartInfo
    $info.FileName=$FilePath
    $info.Arguments=$Arguments
    $info.UseShellExecute=$false
    $info.CreateNoWindow=$true
    $info.RedirectStandardOutput=$true
    $info.RedirectStandardError=$true
    $process=New-Object Diagnostics.Process
    $process.StartInfo=$info
    try {
        if(-not $process.Start()){throw "Could not start: $FilePath"}
        $stdout=$process.StandardOutput.ReadToEndAsync()
        $stderr=$process.StandardError.ReadToEndAsync()
        if(-not $process.WaitForExit($TimeoutMilliseconds)){
            $process.Kill()
            throw "Timed out: $FilePath $Arguments. Child/Windows servicing may still be active; do not run a second instance."
        }
        if(-not $stdout.Wait(5000) -or -not $stderr.Wait(5000)){throw "Output read timed out: $FilePath"}
        if($process.ExitCode -notin $SuccessCodes){throw "$FilePath returned $($process.ExitCode): $($stderr.Result) $($stdout.Result)"}
        if($stderr.Result){Write-Warning $stderr.Result}
        if($process.ExitCode -eq 3010){Write-Output 'Operation succeeded; Windows restart required (3010).'}
        if($PassThru){return [pscustomobject]@{ExitCode=$process.ExitCode;Output=$stdout.Result;Error=$stderr.Result}}
        return $stdout.Result
    } finally {$process.Dispose()}
}
