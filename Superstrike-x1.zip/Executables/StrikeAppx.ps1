#requires -Version 5.1
[CmdletBinding(DefaultParameterSetName='Pattern')]
param(
    [Parameter(Mandatory=$true,ParameterSetName='Pattern')][ValidatePattern('^[A-Za-z0-9.*_-]{2,200}$')][string]$Pattern,
    [Parameter(Mandatory=$true,ParameterSetName='Patterns')][string[]]$Patterns,
    [Parameter(Mandatory=$true,ParameterSetName='Group')][ValidatePattern('^[A-Za-z0-9_-]+$')][string]$Group
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$protected='SecHealth|WindowsDefender|WindowsStore|StorePurchaseApp|StoreExtensions|MicrosoftEdge|Microsoft\.Edge|AAD\.Broker|AccountsControl|BioEnrollment|CredDialog|Windows\.CBSPreview|MicrosoftWindows\.LKG\.|Client\.(CBS|Core|FileExp|OOBE|Photon)|StartMenuExperienceHost|ShellExperienceHost|VCLibs|UI\.Xaml|NET\.Native|DesktopAppInstaller|WindowsAppRuntime|Win32WebViewHost|WebView2'
$directory=Join-Path $env:ProgramData 'StrikeOS\Logs'
$journal=Join-Path $directory 'Appx-Results.jsonl'
function Write-Result([string]$CurrentPattern,[string]$State,[string]$Name,[string]$Detail) {
    $record=[ordered]@{Time=(Get-Date -Format o);Pattern=$CurrentPattern;Name=$Name;State=$State;Detail=$Detail}
    $record|ConvertTo-Json -Compress|Add-Content -LiteralPath $journal -Encoding UTF8
    Write-Output "$($record.Time) AppX $State [$Name]: $Detail"
}
try {
    New-Item -ItemType Directory -Path $directory -Force|Out-Null
    if($PSCmdlet.ParameterSetName -eq 'Group'){
        $path=Join-Path $PSScriptRoot 'StrikeAppx-Patterns.json'
        if(-not (Test-Path -LiteralPath $path -PathType Leaf)){throw 'AppX pattern data not found.'}
        $data=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json
        $property=$data.PSObject.Properties[$Group]
        if($null -eq $property){throw "AppX group not found: $Group"}
        $targets=@($property.Value|ForEach-Object{[string]$_}|Select-Object -Unique)
    } elseif($PSCmdlet.ParameterSetName -eq 'Patterns'){$targets=@($Patterns)}else{$targets=@($Pattern)}
    if(-not $targets.Count){throw 'AppX pattern list is empty.'}
    foreach($item in $targets){if($item -notmatch '^[A-Za-z0-9.*_-]{2,200}$' -or $item -notmatch '[A-Za-z]'){throw "Invalid AppX pattern: $item"}}
    $installed=@(Get-AppxPackage -AllUsers -PackageTypeFilter Main,Bundle)
    $provisioned=@(Get-AppxProvisionedPackage -Online)
    $removeNames=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach($current in $targets){
        Write-Result $current 'Begin' $current 'Batch deployment inventory; no database edits or locking-process termination.'
        $names=@(@($installed|Where-Object{$_.Name -like $current -or $_.PackageFamilyName -like $current}|ForEach-Object Name)+@($provisioned|Where-Object{$_.DisplayName -like $current -or $_.PackageName -like $current}|ForEach-Object DisplayName)|Sort-Object -Unique)
        if(-not $names.Count){Write-Result $current 'Absent' $current 'No matching installed/provisioned package.';continue}
        foreach($name in $names){
            $packages=@($installed|Where-Object Name -EQ $name|Sort-Object IsBundle -Descending)
            if($name -match $protected -or @($packages|Where-Object{$_.NonRemovable -or $_.IsFramework}).Count){Write-Result $current 'RetainedProtected' $name 'System-owned/framework package; not reported as removed.';continue}
            foreach($package in $packages){Write-Result $current 'RemovingInstalled' $name $package.PackageFullName;Remove-AppxPackage -Package $package.PackageFullName -AllUsers -Confirm:$false}
            foreach($package in @($provisioned|Where-Object DisplayName -EQ $name)){Write-Result $current 'RemovingProvisioned' $name $package.PackageName;Remove-AppxProvisionedPackage -Online -PackageName $package.PackageName -AllUsers|Out-Null}
            $null=$removeNames.Add($name)
            $installed=@($installed|Where-Object Name -NE $name)
            $provisioned=@($provisioned|Where-Object DisplayName -NE $name)
            Write-Result $current 'RemovalIssued' $name 'Removal calls completed; final batch read-back pending.'
        }
        Write-Result $current 'PatternProcessed' $current 'Pattern processed; final batch read-back still pending.'
    }
    $remainingInstalled=@(Get-AppxPackage -AllUsers -PackageTypeFilter Main,Bundle)
    $remainingProvisioned=@(Get-AppxProvisionedPackage -Online)
    foreach($name in $removeNames){
        if(@($remainingInstalled|Where-Object Name -EQ $name).Count -or @($remainingProvisioned|Where-Object DisplayName -EQ $name).Count){throw "Package remains after removal: $name"}
        Write-Result '<batch>' 'RemovedVerified' $name 'Installed and provisioned entries absent after batch read-back.'
    }
    foreach($current in $targets){Write-Result $current 'CompletePattern' $current 'Final batch read-back completed.'}
    Write-Output "AppX batch completed: patterns=$($targets.Count); removalTargets=$($removeNames.Count)."
    exit 0
} catch {
    $label=switch($PSCmdlet.ParameterSetName){'Group'{$Group}'Patterns'{'<batch>'}default{$Pattern}}
    [Console]::Error.WriteLine("AppX failed [$label]: $($_.Exception.Message)")
    exit 1
}
